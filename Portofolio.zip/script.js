function showPage(page) {
    // Hide all pages
    document.getElementById('content').innerHTML = "";
  
    if (page === "home") {
      // Home page content
      document.getElementById('content').innerHTML = `
      IAM RAMSON BII AKA MR MORALE


      `;
    } else if (page === "about") {
      // About page content
      document.getElementById('content').innerHTML = `
     IAM A STUDENT AT JKUAT IAM A GAMER IN IT  




      `;
    } else if (page === "dish1") {
      // Dish 1 page content
      document.getElementById('content').innerHTML = `
        <h2>Chapatti nyama</h2>
        <img src="c:\Users\san\Downloads\chapo.jpeg" alt="Chapatti nyama">
         Here's a simple recipe for making chapati:

Ingredients:
2 cups of whole wheat flour (atta)

1/2 teaspoon salt (optional)

3/4 cup water (approximately, adjust as needed)

1 tablespoon oil or ghee (optional, for softer chapatis)

Instructions:
Prepare the dough:

In a large mixing bowl, combine the flour and salt (if using).

Slowly add water little by little, mixing with your hands or a spoon to form a dough.

Once it begins to come together, knead it for about 5-7 minutes until it’s smooth and elastic. If the dough is too sticky, sprinkle a little more flour. If it’s too dry, add a bit more water.

Optionally, you can add oil or ghee to make the dough softer.

Cover the dough with a damp cloth and let it rest for 20-30 minutes. This helps to make the chapatis soft.

Divide the dough:

After resting, divide the dough into small equal-sized balls, about the size of a golf ball.

Roll the dough:

Take one dough ball and flatten it slightly with your fingers.

Dust it lightly with some flour and roll it out into a thin, round disc (approximately 6-8 inches in diameter). Try to keep it even by rolling in all directions.

Cook the chapati:

Heat a tawa (flat griddle) or a large, heavy pan on medium-high heat.

Once hot, place the rolled-out chapati on the tawa. Cook for about 30 seconds or until you see bubbles starting to form on the top.

Flip the chapati using tongs or a spatula, and cook the other side for about 30 seconds.

Once the second side has cooked, press gently with a clean cloth or spatula, allowing the chapati to puff up. Flip it back for a few seconds to cook evenly.

Serve:

Remove the chapati from the tawa and place it in a container lined with a clean cloth to keep it warm.

Repeat the process with the remaining dough balls.

Serve your chapatis hot with curry, dal, or any dish of your choice!

Enjoy!


        
      `;
    } else if (page === "dish2") {
      // Dish 2 page content
      document.getElementById('content').innerHTML = `
      <h2>PIlau</h2>
      <img src="c:\Users\san\Downloads\pilau.jpeg" alt="pilau">
       Ingredients:
2 cups basmati rice (or any long-grain rice)

4 cups water (or chicken/vegetable broth for more flavor)

2 tablespoons oil (vegetable or olive oil)

1 large onion, finely chopped

2 garlic cloves, minced

1 teaspoon cumin seeds (or ground cumin)

1 teaspoon coriander powder

1 teaspoon turmeric powder

1 teaspoon cinnamon powder

2-3 whole cloves

2 cardamom pods (optional)

1 bay leaf

1 medium carrot, grated or diced

1/2 cup peas (frozen or fresh)

Salt, to taste

Black pepper, to taste

Fresh cilantro (optional for garnish)

Instructions:
Prepare the Rice:

Rinse the basmati rice under cold water until the water runs clear. This helps remove excess starch and prevents the rice from becoming sticky.

Cook the Spices:

Heat oil in a large pan or pot over medium heat. Add the cumin seeds and let them sizzle for about 30 seconds.

Add the chopped onion and sauté until it becomes soft and golden brown (about 5-7 minutes).

Stir in the minced garlic and cook for another minute until fragrant.

Add the coriander powder, turmeric powder, cinnamon powder, cloves, cardamom pods, and bay leaf. Stir to combine the spices and cook for another minute to release their flavors.

Cook the Vegetables:

Add the grated carrot and peas to the pan, and cook for about 2-3 minutes until they soften slightly.

Add the Rice:

Add the rinsed rice to the pan and stir gently to coat the rice with the spices and vegetables.

Add Liquid:

Pour in the water or broth. Season with salt and black pepper to taste. Bring the mixture to a boil.

Simmer the Pilau:

Once it boils, reduce the heat to low and cover the pan with a tight-fitting lid. Let it simmer for 15-20 minutes, or until the rice is cooked and the liquid has been absorbed. (If using a different type of rice, follow the cooking instructions for that rice variety.)

Fluff and Serve:

Once the rice is cooked, remove the pan from the heat and let it sit covered for about 5 minutes.

Fluff the rice with a fork to separate the grains.

Garnish:

Optionally, garnish with fresh chopped cilantro for a burst of color and flavor.

Serving:
Serve the pilau on its own as a main dish, or pair it with a side of yogurt, salad, or a protein like grilled chicken, lamb, or beans.

Enjoy your flavorful and aromatic Pilau!
      
        
      `;
    }
  }